package com.example.androkado2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.RatingBar;

import com.example.androkado2.bo.Article;
import com.example.androkado2.dao.ArticlesDAO;

public class AjoutEditActivity extends AppCompatActivity {
    private static final String TAG = "ACOS";
    Article a = null;
    EditText ednom = null;
    EditText eddescription = null;
    EditText edurl= null;
    EditText edprix = null;
    RatingBar edenvie = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_edit);
        ednom = findViewById(R.id.edit_nom);
        eddescription = findViewById(R.id.edit_description);
        edurl= findViewById(R.id.edit_url);
        edprix = findViewById(R.id.edit_prix);
        edenvie = findViewById(R.id.edit_envie);

        // si on arrive suit à une demande de modification

        Intent intention = getIntent();
        a = intention.getParcelableExtra("articleSelectionné");

        // Traitement de l'article (potentiellement) reçu : affichage
        if (a != null)
        {
            ednom.setText(a.getNom());
            eddescription.setText(a.getDescription());
            edurl.setText(a.getUrl());
            edprix.setText(Float.toString(a.getPrix()));
            edenvie.setRating(a.getNote());
        }
        else {
            SharedPreferences spIntra = getSharedPreferences("configuration",MODE_PRIVATE);
            String valeurPrixDefaut = spIntra.getString(ConfigurationActivity.CLE_PRIX_DEFAUT,"");
            edprix.setText(valeurPrixDefaut);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        ArticlesDAO dao = new ArticlesDAO(this);

        if (a != null) {
            a.setNom(ednom.getText().toString());
            a.setDescription(eddescription.getText().toString());
            a.setUrl(edurl.getText().toString());
            a.setPrix(Float.parseFloat(edprix.getText().toString()));
            a.setNote(edenvie.getRating()+1);
            a.setAchete(false);
            dao.update(a);
            Log.i(TAG, "article ds onPause " + a.toString());

            // on se redirige sur l'activité de départ
            Intent intentionResult = new Intent(this, ListeArticlesActivity.class);
            intentionResult.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // On n'empile pas de nouvelle instance, on réutilise la même
            startActivity(intentionResult);
        }
        else {
            Article article = new Article();
            article.setNom(ednom.getText().toString());
            article.setDescription(eddescription.getText().toString());
            article.setUrl(edurl.getText().toString());
            article.setPrix(Float.parseFloat(edprix.getText().toString()));
            article.setNote(edenvie.getRating()+1);
            article.setAchete(false);
            dao.insert(article);
        }
    }
}