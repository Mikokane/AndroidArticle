package com.example.androkado2.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.androkado2.InfoDetailActivity;
import com.example.androkado2.bo.Article;
import com.example.androkado2.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ArticleAdapter  extends ArrayAdapter<Article> {
    private int idPresentationLigne;
    private static final String TAG = "ACOS";
    public ArticleAdapter(@NonNull Context context, int resource, @NonNull List<Article> objects) {
        super(context, resource, objects);
        idPresentationLigne=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View ligneView = inflater.inflate(idPresentationLigne, parent,false);
        final Article art = getItem(position);
        final  ViewGroup p = parent;
        ligneView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG,"Lancement de l'activité Détail");
                Intent intent = new Intent(p.getContext(), InfoDetailActivity.class);
                intent.putExtra("article", art);
                p.getContext().startActivity(intent);
            }
        });

        TextView tvnom = ligneView.findViewById(R.id.tv_nom);
        RatingBar tvscore = ligneView.findViewById(R.id.tv_score);
        tvscore.setRating(art.getNote());
        tvnom.setText(art.getNom());
        return ligneView;
    }
}
