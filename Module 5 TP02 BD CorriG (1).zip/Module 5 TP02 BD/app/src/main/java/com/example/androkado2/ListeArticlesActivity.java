package com.example.androkado2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.androkado2.adapter.ArticleAdapter;
import com.example.androkado2.bo.Article;
import com.example.androkado2.dao.ArticlesDAO;

import java.util.ArrayList;
import java.util.List;

public class ListeArticlesActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private List<Article> articles = new ArrayList<Article>();
    private static final String TAG = "ACOS";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_articles);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }

    @Override
    protected void onResume() {
        super.onResume();
        chargementDonnees();
        ArticleAdapter adapter = new ArticleAdapter(this,R.layout.cell_cards, articles);
        ListView listeArticle = findViewById(R.id.lv_article);
        listeArticle.setAdapter(adapter);
        listeArticle.setOnItemClickListener((AdapterView.OnItemClickListener) this);
        Log.i(TAG,"écouteur positionné");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar_liste, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.item_ajout:
                Intent intentAjout = new Intent(this,AjoutEditActivity.class);
                startActivity(intentAjout);
                return true;
            case R.id.item_configuration:
                Log.i(TAG,"Lancement de l'activité configuration");
                Intent intent = new Intent(this, ConfigurationActivity.class);
                startActivity(intent);
                return true;
        }
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Log.i(TAG,"Lancement de l'activité Détail");
        Intent intent = new Intent(this, InfoDetailActivity.class);
        Article art = articles.get(i);
        intent.putExtra("article", art);
        startActivity(intent);
    }

    /**
     * Permet de charger les données.
     */
    private void chargementDonnees()
    {
        ArticlesDAO dao = new ArticlesDAO(this);
        SharedPreferences spIntra = getSharedPreferences("configuration",MODE_PRIVATE);
        Boolean valeurTri = spIntra.getBoolean(ConfigurationActivity.CLE_TRI,false);

/*        Article a1 = new Article(1,"Guitare","instrument de musique","http://www.guitare.fr",90.99f,3,false);
        dao.insert(a1);
        Article a2 = new Article(2,"Flûte  ","instrument de musique","http://www.flute.fr",59.99f,1,false);
        dao.insert(a2);
        Article a3 = new Article(3,"Basse  ","instrument de musique","http://www.basse.fr",199.99f,4,false);
        dao.insert(a3);*/

        articles = dao.get(valeurTri);
    }

}