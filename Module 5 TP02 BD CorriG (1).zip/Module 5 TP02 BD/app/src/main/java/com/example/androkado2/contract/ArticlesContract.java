package com.example.androkado2.contract;

public class ArticlesContract {
    public static final String TABLE_NAME = "articles";
    public static final String COL_ID = " id ";
    public static final String COL_NOM = " nom ";
    public static final String COL_DESCRIPTION = " description ";
    public static final String COL_URL = " url ";
    public static final String COL_PRIX = " prix ";
    public static final String COL_NOTE = " note ";
    public static final String COL_ISACHETE = " isAchete ";

    public static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME
            +" ( " + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"+
            COL_NOM + " TEXT,"+
            COL_DESCRIPTION + " TEXT,"+
            COL_URL + " TEXT,"+
            COL_PRIX + " FLOAT,"+
            COL_NOTE + " INTEGER,"+
            COL_ISACHETE + " INTEGER"+
            ");";

    public static final String DROP_TABLE = "DROP TABLE " + TABLE_NAME;
}
