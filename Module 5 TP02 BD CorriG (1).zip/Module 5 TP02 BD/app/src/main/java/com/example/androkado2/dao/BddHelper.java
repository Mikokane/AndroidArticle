package com.example.androkado2.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.androkado2.contract.ArticlesContract;

public class BddHelper extends SQLiteOpenHelper {
    private final static int VERSION = 4;
    private final static String BDD_NAME = "articles.db";
    private final static String TAG = "ACOS";

    public BddHelper(Context context) {
        super(context, BDD_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.i(TAG,"Passage dans le onCreate "+ ArticlesContract.CREATE_TABLE);
        sqLiteDatabase.execSQL(ArticlesContract.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.i(TAG,"Passage dans le onUpgrade");
        sqLiteDatabase.execSQL(ArticlesContract.DROP_TABLE);
        onCreate(sqLiteDatabase);
    }

}
