package com.example.androkado2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.androkado2.bo.Article;
import com.example.androkado2.dao.ArticlesDAO;

public class InfoDetailActivity<OnResume> extends AppCompatActivity {
    private static final String TAG = "ACOS";
    private static final int REQUEST_CODE = 13;
    Article article = null;
    TextView tvId ;
    TextView tvNom ;
    TextView tvDescription;
    TextView tvPrix;
    RatingBar rating;
    ToggleButton toggle ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_detail);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar_detail);
        setSupportActionBar(myToolbar);

        Intent intent = getIntent();
        article = intent.getParcelableExtra("article");

        tvId =  findViewById(R.id.tv_ident);
        tvNom =  findViewById(R.id.tv_nom);
        tvDescription = findViewById(R.id.tv_description);
        tvPrix = findViewById(R.id.tv_prix);
        rating = findViewById(R.id.rating_article);
        toggle = findViewById(R.id.btn_achete);
     }

    @Override
    protected void onResume()
    {
        super.onResume();
        chargementDonnees(article);
    }

    private void chargementDonnees(Article article)
    {
        if (article!= null) {
            tvId.setText(String.valueOf(article.getId()));
            tvNom.setText(article.getNom());
            tvDescription.setText(article.getDescription());
            tvPrix.setText(String.valueOf(article.getPrix()));
            rating.setRating(article.getNote());
            toggle.setChecked(article.isAchete());
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.item_modifier:
                Log.i(TAG, "modification de l'article");
                Intent intent = new Intent(this, AjoutEditActivity.class);
                intent.putExtra("articleSelectionné", article);
                startActivity(intent);
                return true;
            case R.id.item_supprimer:
                Log.i(TAG, "suppression de l'article");
                ArticlesDAO dao = new ArticlesDAO(this);
                dao.delete(article);
                this.finish();
                return true;
            case R.id.item_envoyer:
                Toast.makeText(this, "Envoyer", Toast.LENGTH_SHORT).show();
                return true;
        }
        return true;
    }

    public void onClickUrl(View view) {
        try {
            Intent intention = new Intent(Intent.ACTION_VIEW);
            String url = article.getUrl();
            intention.setData(Uri.parse("https://"+url));
            startActivity(intention);
        } catch (ActivityNotFoundException anfe) {
            Log.e("IntentionImplicite", "surfer", anfe);
        }
    }

    public void onClickAchat(View view)
    {
        article.setAchete(!article.isAchete());
        Log.i(TAG,"Valeur achat " + article.isAchete());
    }
}