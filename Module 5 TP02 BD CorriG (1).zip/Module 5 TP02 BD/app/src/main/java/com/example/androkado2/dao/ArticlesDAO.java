package com.example.androkado2.dao;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.androkado2.ConfigurationActivity;
import com.example.androkado2.bo.Article;
import com.example.androkado2.contract.ArticlesContract;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class ArticlesDAO {
    private SQLiteDatabase db;
    private BddHelper helper;
    private final static String TAG = "ACOS";

    public ArticlesDAO(Context context) {
        helper = new BddHelper(context);
        db = helper.getWritableDatabase();
    }

    public long insert(Article article) {
        ContentValues values = new ContentValues();
        values.put(ArticlesContract.COL_NOM,article.getNom());
        values.put(ArticlesContract.COL_DESCRIPTION,article.getDescription());
        values.put(ArticlesContract.COL_URL,article.getUrl());
        values.put(ArticlesContract.COL_PRIX,article.getPrix());
        values.put(ArticlesContract.COL_NOTE,article.getNote());
        values.put(ArticlesContract.COL_ISACHETE,article.isAchete());
        return db.insert(ArticlesContract.TABLE_NAME,null,values);
    }

    public Article get(Integer id){
        Article resultat = new Article();

        // Ouvrir la connexion
        db = helper.getWritableDatabase();

        String whereClause =  ArticlesContract.COL_ID+" == ?";
        String[] whereParams = new String[]{Integer.toString(id)};

        Cursor curseur = db.query(ArticlesContract.TABLE_NAME, null, whereClause, whereParams, null, null, null);

        if (curseur.moveToNext())
        {
            resultat = new Article(curseur.getInt(0), // id
                    curseur.getString(1), // Nom
                    curseur.getString(2),// Description
                    curseur.getString(3), // URL
                    curseur.getFloat(4), // Prix
                    curseur.getInt(5), // note
                    curseur.getInt(6)==1// Achete
            );
        }

        curseur.close();

        // Fermer la connexion
        helper.close();
        return resultat;
    }

    public ArrayList<Article> get(Boolean triPrix){
        ArrayList<Article> articles = new ArrayList<Article>();
        Article article = new Article();
        Cursor curseur = null;

        // Ouvrir la connexion
        db = helper.getWritableDatabase();

        if (triPrix) {
            curseur = db.query(ArticlesContract.TABLE_NAME, null, null, null, null, null, ArticlesContract.COL_PRIX);
        }
        else {
            curseur = db.query(ArticlesContract.TABLE_NAME, null, null, null, null, null, null);
        }
        while(curseur.moveToNext()){

            article = new Article(curseur.getInt(0), // id
                    curseur.getString(1), // Nom
                    curseur.getString(2),// Description
                    curseur.getString(3), // URL
                    curseur.getFloat(4), // Prix
                    curseur.getInt(5), // note
                    curseur.getInt(6)==1// Achete
            );
            Log.i(TAG, article.toString());
            articles.add(article);
        }
        curseur.close();

        // Fermer la connexion
        helper.close();
        return articles;
    }

    public void update(Article article){
        // Ouvrir la connexion
        db = helper.getWritableDatabase();

        Log.d(TAG, "Entrée dans update() = " + article.toString());
        ContentValues values = new ContentValues();
        values.put(ArticlesContract.COL_NOM,article.getNom());
        values.put(ArticlesContract.COL_DESCRIPTION,article.getDescription());
        values.put(ArticlesContract.COL_URL,article.getUrl());
        values.put(ArticlesContract.COL_PRIX,article.getPrix());
        values.put(ArticlesContract.COL_NOTE,article.getNote());
        values.put(ArticlesContract.COL_ISACHETE,article.isAchete());
        int nbLignesModifiees = db.update(
                ArticlesContract.TABLE_NAME,
                values,
                ArticlesContract.COL_ID + "= ?",
                new String[]{String.valueOf(article.getId())}
        );

        Log.d(TAG, "nbLignesModifiées = " + nbLignesModifiees);

        // Fermer la connexion
        helper.close();
    }

    public void delete(Article article)
    {
        // Ouvrir la connexion
        db = helper.getWritableDatabase();

        String whereClause =  ArticlesContract.COL_ID+" == ?";
        String[] whereParams = new String[]{Integer.toString(article.getId())};

        // Passer la requete
        int nbLignessupprimees = db.delete(ArticlesContract.TABLE_NAME, whereClause, whereParams);
        Log.d(TAG, "nbLignessupprimées = " + nbLignessupprimees);

        // Fermer la connexion
        helper.close();
    }

}
